# 🫁 ICU Mechanical Ventilation Risk Predictor

A Streamlit app for predicting ICU patient ventilation risk 6–12 hours in advance.

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

## App Structure

```
icu_app/
├── app.py                  # Main entry point
├── requirements.txt
└── pages/
    ├── home.py             # Project overview & feature summary
    ├── eda.py              # Exploratory Data Analysis
    ├── training.py         # Model training & evaluation
    ├── results.py          # Full results comparison
    └── predict.py          # Single patient prediction
```

## Pages

| Page | Description |
|------|-------------|
| 🏠 Home | Project overview, data sources, feature groups |
| 📊 EDA | Upload data, explore distributions & missing values |
| 🤖 Model Training | Train LR / RF / XGBoost with any imbalance strategy |
| 📈 Results | Compare all 9 experiments side-by-side |
| 🔮 Predict | Enter patient vitals and get a risk prediction |

## Data Files Required
Place these in the same folder as `app.py`:
- `X_train.csv`, `y_train.csv`
- `X_test.csv`, `y_test.csv`

## Best Model
**Random Forest + `class_weight='balanced_subsample'`**
- AUPRC: 0.0031 | AUROC: 0.645 | Recall: 50%
