import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# All known results from experiments
KNOWN_RESULTS = [
    {"Model": "Logistic Regression", "Strategy": "class_weight='balanced'",       "AUPRC": 0.0015, "AUROC": 0.400, "Best F1": 0.000, "Recall (Vent)": "10/48",  "Best": False},
    {"Model": "Random Forest",        "Strategy": "class_weight='balanced_sub.'",  "AUPRC": 0.0031, "AUROC": 0.645, "Best F1": 0.011, "Recall (Vent)": "24/48",  "Best": True},
    {"Model": "XGBoost",              "Strategy": "scale_pos_weight=436.9",        "AUPRC": 0.0032, "AUROC": 0.632, "Best F1": 0.012, "Recall (Vent)": "8/48",   "Best": False},
    {"Model": "XGBoost",              "Strategy": "SMOTE",                         "AUPRC": 0.0030, "AUROC": 0.590, "Best F1": 0.020, "Recall (Vent)": "2/48",   "Best": False},
    {"Model": "XGBoost",              "Strategy": "SMOTE + Tomek",                 "AUPRC": 0.0030, "AUROC": 0.590, "Best F1": 0.020, "Recall (Vent)": "2/48",   "Best": False},
    {"Model": "XGBoost",              "Strategy": "ADASYN",                        "AUPRC": 0.0030, "AUROC": 0.590, "Best F1": 0.020, "Recall (Vent)": "13/48",  "Best": False},
    {"Model": "Random Forest",        "Strategy": "SMOTE",                         "AUPRC": 0.0040, "AUROC": 0.663, "Best F1": 0.014, "Recall (Vent)": "15/48",  "Best": False},
    {"Model": "Random Forest",        "Strategy": "SMOTE + Tomek",                 "AUPRC": 0.0040, "AUROC": 0.663, "Best F1": 0.014, "Recall (Vent)": "15/48",  "Best": False},
    {"Model": "Random Forest",        "Strategy": "ADASYN",                        "AUPRC": 0.0040, "AUROC": 0.663, "Best F1": 0.014, "Recall (Vent)": "15/48",  "Best": False},
]

def show():
    st.title("📈 Results & Comparison")
    st.markdown("Full comparison of all models and imbalance strategies.")
    st.markdown("---")

    # Merge known + session results
    all_results = KNOWN_RESULTS.copy()
    if "results_log" in st.session_state and st.session_state["results_log"]:
        for r in st.session_state["results_log"]:
            r_copy = r.copy(); r_copy["Best"] = False
            all_results.append(r_copy)
        st.info(f"+ {len(st.session_state['results_log'])} result(s) added from your training session.")

    df = pd.DataFrame(all_results)

    # ── Top metrics ──────────────────────────────────────────────────────────
    best = df.loc[df["AUPRC"].idxmax()]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("🥇 Best Model",    best["Model"])
    c2.metric("🥇 Best Strategy", best["Strategy"])
    c3.metric("🥇 Best AUPRC",    f"{best['AUPRC']:.4f}")
    c4.metric("🥇 Best AUROC",    f"{best['AUROC']:.4f}")

    st.markdown("---")

    # ── Full table ───────────────────────────────────────────────────────────
    st.subheader("📋 All Experiments")

    def highlight_best(row):
        if row.get("Best", False):
            return ["background-color: #d6f0e0; font-weight: bold"] * len(row)
        return [""] * len(row)

    display_df = df.drop(columns=["Best"])
    st.dataframe(
        display_df.style.apply(highlight_best, axis=1),
        use_container_width=True,
        height=380,
    )

    st.markdown("---")

    # ── Charts ───────────────────────────────────────────────────────────────
    tab1, tab2, tab3 = st.tabs(["AUPRC Comparison", "AUROC Comparison", "Model Deep-Dive"])

    with tab1:
        st.subheader("AUPRC by Model & Strategy")
        fig, ax = plt.subplots(figsize=(12, 5))
        colors_map = {"Logistic Regression": "#9333ea", "Random Forest": "#16a34a", "XGBoost": "#f97316"}
        x = np.arange(len(df))
        bars = ax.bar(x, df["AUPRC"],
                      color=[colors_map.get(m, "#2563eb") for m in df["Model"]],
                      edgecolor="white", width=0.6)
        ax.axhline(0.0018, color="gray", linestyle="--", lw=1.2, label="Random baseline=0.0018")
        for bar, val in zip(bars, df["AUPRC"]):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.00005,
                    f"{val:.4f}", ha="center", va="bottom", fontsize=8, fontweight="bold")
        labels = [f"{r['Model'].split()[0]}\n{r['Strategy'][:18]}" for _, r in df.iterrows()]
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=8)
        ax.set_ylabel("AUPRC"); ax.set_title("AUPRC Across All Experiments")
        ax.legend(); ax.grid(axis="y", alpha=0.3)
        # Legend for colors
        from matplotlib.patches import Patch
        legend_els = [Patch(facecolor=c, label=m) for m, c in colors_map.items()]
        ax.legend(handles=legend_els + [plt.Line2D([0],[0], color="gray", linestyle="--", label="Baseline")])
        plt.tight_layout()
        st.pyplot(fig)

    with tab2:
        st.subheader("AUROC by Model & Strategy")
        fig2, ax2 = plt.subplots(figsize=(12, 5))
        bars2 = ax2.bar(x, df["AUROC"],
                        color=[colors_map.get(m, "#2563eb") for m in df["Model"]],
                        edgecolor="white", width=0.6)
        ax2.axhline(0.5, color="gray", linestyle="--", lw=1.2, label="Random baseline=0.5")
        for bar, val in zip(bars2, df["AUROC"]):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.002,
                     f"{val:.3f}", ha="center", va="bottom", fontsize=8, fontweight="bold")
        ax2.set_xticks(x); ax2.set_xticklabels(labels, rotation=30, ha="right", fontsize=8)
        ax2.set_ylabel("AUROC"); ax2.set_title("AUROC Across All Experiments")
        ax2.set_ylim(0, 0.8); ax2.legend(); ax2.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig2)

    with tab3:
        st.subheader("Model Deep-Dive")
        selected_model = st.selectbox("Select model", df["Model"].unique())
        sub = df[df["Model"] == selected_model]

        st.dataframe(sub.drop(columns=["Best"]), use_container_width=True)

        fig3, axes3 = plt.subplots(1, 2, figsize=(10, 4))
        axes3[0].bar(sub["Strategy"], sub["AUPRC"], color="#2563eb", edgecolor="white")
        axes3[0].set_title(f"{selected_model} — AUPRC by Strategy")
        axes3[0].set_ylabel("AUPRC"); axes3[0].grid(axis="y", alpha=0.3)
        plt.setp(axes3[0].xaxis.get_majorticklabels(), rotation=20, ha="right")

        axes3[1].bar(sub["Strategy"], sub["AUROC"], color="#16a34a", edgecolor="white")
        axes3[1].set_title(f"{selected_model} — AUROC by Strategy")
        axes3[1].set_ylabel("AUROC"); axes3[1].grid(axis="y", alpha=0.3)
        plt.setp(axes3[1].xaxis.get_majorticklabels(), rotation=20, ha="right")
        plt.tight_layout()
        st.pyplot(fig3)

    # ── Key findings ──────────────────────────────────────────────────────────
    st.markdown("---")
    st.subheader("🔍 Key Findings")
    col_a, col_b = st.columns(2)
    with col_a:
        st.success("🥇 **Best model:** Random Forest + `class_weight='balanced_subsample'`\n\nAUPRC=0.0031, AUROC=0.645, Recall=50%")
        st.info("📌 **SMOTE + Tomek = SMOTE** — identical results suggest no meaningful boundary overlap")
        st.info("📌 **ADASYN** was consistently the best SMOTE variant across both models")
    with col_b:
        st.warning("⚠️ **SMOTE hurt XGBoost** — recall dropped from 17% → 4%. XGBoost handles imbalance better via `scale_pos_weight`")
        st.warning("⚠️ **All models hit same ceiling** — precision stuck at ~1%. The bottleneck is feature engineering, not the model.")
        st.error("🔴 **Next step:** Extend rolling windows to 6h/12h and add clinical interaction features")
