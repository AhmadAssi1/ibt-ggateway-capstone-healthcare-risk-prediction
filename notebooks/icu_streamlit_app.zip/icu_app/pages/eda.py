import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def show():
    st.title("📊 Exploratory Data Analysis")
    st.markdown("Upload your processed train/test data to explore distributions and missing patterns.")
    st.markdown("---")

    # ── File upload ──────────────────────────────────────────────────────────
    col1, col2 = st.columns(2)
    with col1:
        x_file = st.file_uploader("Upload X_train.csv", type="csv", key="eda_x")
    with col2:
        y_file = st.file_uploader("Upload y_train.csv", type="csv", key="eda_y")

    if not x_file or not y_file:
        st.info("👆 Upload X_train.csv and y_train.csv to begin EDA.")

        # Show static summary from known results
        st.markdown("---")
        st.subheader("📋 Known Dataset Statistics")
        stats = pd.DataFrame({
            "Table":    ["patient", "resp_care", "vital_periodic", "resp_chart", "treatment"],
            "Key Columns": ["age, gender, unittype, admissionweight", "ventstartoffset (labels)",
                            "heartrate, sao2, respiration", "FiO2, PEEP, oxygen therapy", "treatmentstring"],
            "Missing Issue": ["dischargeweight ~51% missing", "90–100% sparse columns dropped",
                              "sao2 ~15% missing", "label/value ~5% missing", "minimal missing"],
        })
        st.dataframe(stats, use_container_width=True)
        return

    # ── Load data ────────────────────────────────────────────────────────────
    X = pd.read_csv(x_file)
    y = pd.read_csv(y_file).squeeze()

    st.success(f"Loaded: {X.shape[0]:,} rows × {X.shape[1]} features")

    # ── Tab layout ───────────────────────────────────────────────────────────
    tab1, tab2, tab3, tab4 = st.tabs(["📌 Overview", "⚠️ Missing Values", "📉 Distributions", "🎯 Target Balance"])

    # ── Tab 1: Overview ──────────────────────────────────────────────────────
    with tab1:
        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Shape & Types")
            st.metric("Rows",     f"{X.shape[0]:,}")
            st.metric("Features", X.shape[1])
            numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
            st.metric("Numeric features", len(numeric_cols))
        with col_b:
            st.subheader("Summary Statistics")
            st.dataframe(X.describe().T.round(3), use_container_width=True)

    # ── Tab 2: Missing Values ────────────────────────────────────────────────
    with tab2:
        miss = (X.isna().sum() / len(X) * 100).round(2)
        miss = miss[miss > 0].sort_values(ascending=False)

        if miss.empty:
            st.success("✅ No missing values in this dataset!")
        else:
            st.warning(f"{len(miss)} columns have missing values")
            fig, ax = plt.subplots(figsize=(10, max(3, len(miss) * 0.4)))
            colors = ["#dc2626" if v > 50 else "#f97316" if v > 20 else "#facc15" for v in miss.values]
            ax.barh(miss.index[::-1], miss.values[::-1], color=colors[::-1])
            ax.set_xlabel("Missing (%)")
            ax.set_title("Missing Values by Feature")
            ax.axvline(50, color="red", linestyle="--", alpha=0.5, label="50% threshold")
            ax.legend()
            ax.grid(axis="x", alpha=0.3)
            plt.tight_layout()
            st.pyplot(fig)

    # ── Tab 3: Distributions ─────────────────────────────────────────────────
    with tab3:
        st.subheader("Feature Distributions")
        feature = st.selectbox("Select feature", X.select_dtypes(include=np.number).columns.tolist())

        df_plot = X[[feature]].copy()
        df_plot["label"] = y.values

        fig, axes = plt.subplots(1, 2, figsize=(12, 4))

        # Histogram by class
        for label, color, name in [(0, "#2563eb", "No Vent"), (1, "#dc2626", "Vent")]:
            subset = df_plot[df_plot["label"] == label][feature].dropna()
            axes[0].hist(subset, bins=40, alpha=0.6, color=color, label=f"{name} (n={len(subset):,})")
        axes[0].set_title(f"{feature} — Distribution by Class")
        axes[0].set_xlabel(feature)
        axes[0].legend()
        axes[0].grid(alpha=0.3)

        # Boxplot
        bp_data = [df_plot[df_plot["label"] == 0][feature].dropna(),
                   df_plot[df_plot["label"] == 1][feature].dropna()]
        axes[1].boxplot(bp_data, labels=["No Vent (0)", "Vent (1)"],
                        patch_artist=True,
                        boxprops=dict(facecolor="#BDD7EE"),
                        medianprops=dict(color="#dc2626", linewidth=2))
        axes[1].set_title(f"{feature} — Boxplot by Class")
        axes[1].grid(alpha=0.3)

        plt.tight_layout()
        st.pyplot(fig)

    # ── Tab 4: Target Balance ────────────────────────────────────────────────
    with tab4:
        st.subheader("Class Distribution — y_high")
        counts = y.value_counts()
        total  = len(y)

        col1, col2, col3 = st.columns(3)
        col1.metric("Total samples",       f"{total:,}")
        col2.metric("Negative (No Vent)",  f"{counts.get(0, 0):,}",  f"{counts.get(0,0)/total*100:.2f}%")
        col3.metric("Positive (Vent)",     f"{counts.get(1, 0):,}",  f"{counts.get(1,0)/total*100:.2f}%")

        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        labels = ["No Vent (0)", "Vent (1)"]
        colors = ["#2563eb", "#dc2626"]

        axes[0].bar(labels, [counts.get(0,0), counts.get(1,0)], color=colors, edgecolor="white")
        axes[0].set_title("Class Counts")
        axes[0].set_ylabel("Count")
        axes[0].grid(axis="y", alpha=0.3)
        for i, v in enumerate([counts.get(0,0), counts.get(1,0)]):
            axes[0].text(i, v + total*0.005, f"{v:,}", ha="center", fontweight="bold")

        axes[1].pie([counts.get(0,0), counts.get(1,0)], labels=labels, colors=colors,
                    autopct='%1.2f%%', startangle=90,
                    wedgeprops=dict(edgecolor='white', linewidth=2))
        axes[1].set_title("Class Proportions")

        plt.tight_layout()
        st.pyplot(fig)

        ratio = counts.get(0, 0) / max(counts.get(1, 1), 1)
        st.warning(f"⚠️ Severe class imbalance: **{ratio:.0f}:1** — this is why AUPRC is used as the primary metric instead of accuracy.")
