import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    average_precision_score, precision_recall_curve,
    roc_auc_score, classification_report,
    confusion_matrix, ConfusionMatrixDisplay,
)

def show():
    st.title("🤖 Model Training")
    st.markdown("Upload your data, choose a model and imbalance strategy, then train and evaluate.")
    st.markdown("---")

    # ── File Upload ──────────────────────────────────────────────────────────
    st.subheader("1️⃣  Upload Data")
    c1, c2, c3, c4 = st.columns(4)
    xtr = c1.file_uploader("X_train.csv", type="csv", key="tr_xtr")
    ytr = c2.file_uploader("y_train.csv", type="csv", key="tr_ytr")
    xte = c3.file_uploader("X_test.csv",  type="csv", key="tr_xte")
    yte = c4.file_uploader("y_test.csv",  type="csv", key="tr_yte")

    if not all([xtr, ytr, xte, yte]):
        st.info("👆 Upload all 4 CSV files to enable training.")
        return

    X_train = pd.read_csv(xtr)
    y_train = pd.read_csv(ytr).squeeze()
    X_test  = pd.read_csv(xte)
    y_test  = pd.read_csv(yte).squeeze()

    pos = int(y_train.sum()); neg = int((y_train == 0).sum())
    st.success(f"Data loaded — Train: {X_train.shape} | Test: {X_test.shape} | Imbalance: {neg/pos:.0f}:1")

    st.markdown("---")
    st.subheader("2️⃣  Configure Model")

    col_m, col_s = st.columns(2)

    with col_m:
        model_choice = st.selectbox("Model", [
            "Logistic Regression",
            "Random Forest",
            "XGBoost (requires xgboost installed)",
        ])

    with col_s:
        if "Logistic" in model_choice:
            strategy = st.selectbox("Imbalance Strategy", ["class_weight='balanced'"])
        elif "Random Forest" in model_choice:
            strategy = st.selectbox("Imbalance Strategy", [
                "class_weight='balanced_subsample'",
                "SMOTE", "SMOTE + Tomek", "ADASYN"
            ])
        else:
            strategy = st.selectbox("Imbalance Strategy", [
                "scale_pos_weight", "SMOTE", "SMOTE + Tomek", "ADASYN"
            ])

    # ── Hyperparameters ──────────────────────────────────────────────────────
    with st.expander("⚙️ Hyperparameters", expanded=False):
        if "Logistic" in model_choice:
            C = st.slider("C (regularization inverse)", 0.01, 10.0, 1.0, 0.01)
            max_iter = st.slider("max_iter", 100, 2000, 1000, 100)
        elif "Random Forest" in model_choice:
            n_estimators  = st.slider("n_estimators", 50, 500, 300, 50)
            max_depth     = st.slider("max_depth", 3, 20, 10)
            min_samples   = st.slider("min_samples_leaf", 1, 50, 10)
        else:
            n_estimators  = st.slider("n_estimators", 100, 1000, 500, 50)
            lr_xgb        = st.slider("learning_rate", 0.01, 0.3, 0.05, 0.01)
            max_depth_xgb = st.slider("max_depth", 3, 10, 6)

    smote_ratio = 0.1
    if "SMOTE" in strategy or "ADASYN" in strategy:
        smote_ratio = st.slider("SMOTE sampling_strategy (minority/majority ratio)", 0.05, 0.5, 0.1, 0.05)

    # ── Train button ─────────────────────────────────────────────────────────
    st.markdown("---")
    if st.button("🚀 Train Model", type="primary"):
        with st.spinner("Training... please wait"):

            # Apply SMOTE if needed
            X_res, y_res = X_train.copy(), y_train.copy()
            if "SMOTE" in strategy or "ADASYN" in strategy:
                try:
                    from imblearn.over_sampling import SMOTE, ADASYN
                    from imblearn.combine import SMOTETomek
                    if strategy == "SMOTE":
                        sampler = SMOTE(sampling_strategy=smote_ratio, random_state=42)
                    elif strategy == "SMOTE + Tomek":
                        sampler = SMOTETomek(smote=SMOTE(sampling_strategy=smote_ratio, random_state=42), random_state=42)
                    else:
                        sampler = ADASYN(sampling_strategy=smote_ratio, random_state=42)
                    X_res, y_res = sampler.fit_resample(X_train, y_train)
                    st.info(f"After resampling → Pos={int(y_res.sum())} | Neg={int((y_res==0).sum())}")
                except ImportError:
                    st.error("imbalanced-learn not installed. Run: pip install imbalanced-learn")
                    return

            # Build model
            if "Logistic" in model_choice:
                model = Pipeline([
                    ("scaler", StandardScaler()),
                    ("clf", LogisticRegression(class_weight="balanced", C=C, max_iter=max_iter, random_state=42))
                ])
            elif "Random Forest" in model_choice:
                cw = "balanced_subsample" if "class_weight" in strategy else None
                model = RandomForestClassifier(
                    n_estimators=n_estimators, max_depth=max_depth,
                    min_samples_leaf=min_samples, class_weight=cw,
                    n_jobs=-1, random_state=42,
                )
            else:
                try:
                    import xgboost as xgb
                    spw = (neg / pos) if strategy == "scale_pos_weight" else 1
                    model = xgb.XGBClassifier(
                        n_estimators=n_estimators, learning_rate=lr_xgb,
                        max_depth=max_depth_xgb, scale_pos_weight=spw,
                        eval_metric="aucpr", use_label_encoder=False,
                        random_state=42, n_jobs=-1,
                    )
                except ImportError:
                    st.error("XGBoost not installed. Run: pip install xgboost")
                    return

            model.fit(X_res, y_res)

        # ── Evaluate ─────────────────────────────────────────────────────────
        y_prob = model.predict_proba(X_test)[:, 1]
        auprc  = average_precision_score(y_test, y_prob)
        auroc  = roc_auc_score(y_test, y_prob)

        prec, rec, thr = precision_recall_curve(y_test, y_prob)
        f1  = 2 * prec[:-1] * rec[:-1] / (prec[:-1] + rec[:-1] + 1e-8)
        idx = np.argmax(f1)
        best_thr = thr[idx]
        y_pred = (y_prob >= best_thr).astype(int)

        # ── Metrics ───────────────────────────────────────────────────────────
        st.markdown("---")
        st.subheader("📊 Results")
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("AUPRC",          f"{auprc:.4f}")
        m2.metric("AUROC",          f"{auroc:.4f}")
        m3.metric("Best Threshold", f"{best_thr:.3f}")
        m4.metric("Best F1",        f"{f1[idx]:.3f}")

        vc = pd.Series(y_pred).value_counts()
        recall_vent = int(y_pred[y_test == 1].sum())
        st.markdown(f"**Ventilation cases caught:** {recall_vent} / {int(y_test.sum())} ({recall_vent/max(int(y_test.sum()),1)*100:.0f}% recall)")

        # ── Plots ─────────────────────────────────────────────────────────────
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        fig.suptitle(f"{model_choice.split('(')[0].strip()} + {strategy}", fontsize=12, fontweight="bold")

        baseline = y_test.mean()
        axes[0].plot(rec, prec, color="#2563eb", lw=2, label=f"AUPRC={auprc:.4f}")
        axes[0].axhline(baseline, color="gray", linestyle="--", label=f"Baseline={baseline:.4f}")
        axes[0].set_xlabel("Recall"); axes[0].set_ylabel("Precision")
        axes[0].set_title("Precision-Recall Curve"); axes[0].legend(); axes[0].grid(alpha=0.3)

        axes[1].plot(thr, f1, color="#16a34a", lw=2)
        axes[1].axvline(best_thr, color="red", linestyle="--", label=f"Best={best_thr:.3f}")
        axes[1].set_xlabel("Threshold"); axes[1].set_ylabel("F1")
        axes[1].set_title("F1 vs Threshold"); axes[1].legend(); axes[1].grid(alpha=0.3)

        cm   = confusion_matrix(y_test, y_pred)
        disp = ConfusionMatrixDisplay(cm, display_labels=["No Vent", "Vent"])
        disp.plot(ax=axes[2], colorbar=False, cmap="Blues")
        axes[2].set_title(f"Confusion Matrix (thr={best_thr:.3f})")

        plt.tight_layout()
        st.pyplot(fig)

        # Classification report
        with st.expander("📋 Full Classification Report"):
            st.code(classification_report(y_test, y_pred, target_names=["No Vent", "Vent"]))

        # Feature importance
        clf = model.named_steps.get("clf", model) if hasattr(model, "named_steps") else model
        if hasattr(clf, "feature_importances_"):
            imp = pd.Series(clf.feature_importances_, index=X_train.columns).sort_values(ascending=False).head(15)
            with st.expander("🔍 Top 15 Feature Importances"):
                fig2, ax2 = plt.subplots(figsize=(8, 5))
                ax2.barh(imp.index[::-1], imp.values[::-1], color="#2563eb")
                ax2.set_xlabel("Importance"); ax2.set_title("Feature Importances")
                ax2.grid(axis="x", alpha=0.3)
                plt.tight_layout()
                st.pyplot(fig2)

        # Save result to session for Results page
        if "results_log" not in st.session_state:
            st.session_state["results_log"] = []
        st.session_state["results_log"].append({
            "Model":     model_choice.split("(")[0].strip(),
            "Strategy":  strategy,
            "AUPRC":     round(auprc, 4),
            "AUROC":     round(auroc, 4),
            "Best F1":   round(f1[idx], 3),
            "Recall (Vent)": f"{recall_vent}/{int(y_test.sum())}",
        })
        st.success("✅ Result saved to Results & Comparison page!")
