import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "heartrate_last", "sao2_last", "respiration_last", "fio2_last", "peep_last",
    "on_oxygen_therapy", "on_noninvasive_vent", "age", "admissionweight",
    "heartrate_mean_3h", "heartrate_std_3h", "heartrate_slope_3h",
    "sao2_mean_3h", "sao2_std_3h", "sao2_slope_3h",
    "respiration_mean_3h", "respiration_std_3h", "respiration_slope_3h",
    "hr_missing", "sao2_missing", "fio2_missing",
    "unittype_CCU-CTICU", "unittype_CSICU", "unittype_CTICU", "unittype_Cardiac ICU",
    "unittype_MICU", "unittype_Med-Surg ICU", "unittype_Neuro ICU", "unittype_SICU",
    "gender_Female", "gender_Male",
]

def show():
    st.title("🔮 Patient Risk Prediction")
    st.markdown("Enter patient vitals and clinical details to predict ventilation risk in the next 6–12 hours.")
    st.markdown("---")

    st.subheader("1️⃣  Train Model (required before predicting)")
    c1, c2, c3, c4 = st.columns(4)
    xtr = c1.file_uploader("X_train.csv", type="csv", key="pred_xtr")
    ytr = c2.file_uploader("y_train.csv", type="csv", key="pred_ytr")
    xte = c3.file_uploader("X_test.csv",  type="csv", key="pred_xte")
    yte = c4.file_uploader("y_test.csv",  type="csv", key="pred_yte")

    model_ready = False

    if all([xtr, ytr, xte, yte]):
        X_train = pd.read_csv(xtr); y_train = pd.read_csv(ytr).squeeze()
        X_test  = pd.read_csv(xte); y_test  = pd.read_csv(yte).squeeze()

        if st.button("🏋️ Train Random Forest (Best Model)", type="primary"):
            with st.spinner("Training..."):
                model = RandomForestClassifier(
                    n_estimators=300, max_depth=10, min_samples_leaf=10,
                    class_weight="balanced_subsample", n_jobs=-1, random_state=42,
                )
                model.fit(X_train, y_train)
                st.session_state["pred_model"]    = model
                st.session_state["pred_features"] = X_train.columns.tolist()
            st.success("✅ Model trained and ready!")

    model_ready = "pred_model" in st.session_state

    if not model_ready:
        st.info("👆 Upload data and train the model to enable predictions.")
        st.markdown("---")
        st.subheader("Preview: What the input form looks like")

    # ── Patient Input Form ───────────────────────────────────────────────────
    st.markdown("---")
    st.subheader("2️⃣  Enter Patient Vitals")

    with st.form("patient_form"):
        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown("**❤️ Heart Rate**")
            heartrate_last      = st.number_input("Last HR (bpm)",          0.0, 250.0, 85.0)
            heartrate_mean_3h   = st.number_input("Mean HR — 3h (bpm)",     0.0, 250.0, 85.0)
            heartrate_std_3h    = st.number_input("Std HR — 3h",            0.0, 50.0,  5.0)
            heartrate_slope_3h  = st.number_input("Slope HR — 3h",         -10.0, 10.0, 0.0)
            hr_missing          = st.selectbox("HR missing?", [0, 1], format_func=lambda x: "Yes" if x else "No")

            st.markdown("**👤 Demographics**")
            age                 = st.number_input("Age (years)",             0.0, 100.0, 65.0)
            admissionweight     = st.number_input("Admission weight (kg)",   0.0, 300.0, 80.0)
            gender_female       = st.selectbox("Gender", ["Female", "Male"])

        with col2:
            st.markdown("**🫧 SpO2**")
            sao2_last           = st.number_input("Last SpO2 (%)",           50.0, 100.0, 97.0)
            sao2_mean_3h        = st.number_input("Mean SpO2 — 3h (%)",      50.0, 100.0, 97.0)
            sao2_std_3h         = st.number_input("Std SpO2 — 3h",           0.0,  10.0,  1.0)
            sao2_slope_3h       = st.number_input("Slope SpO2 — 3h",        -5.0,   5.0,  0.0)
            sao2_missing        = st.selectbox("SpO2 missing?", [0, 1], format_func=lambda x: "Yes" if x else "No")

            st.markdown("**💨 Respiration**")
            respiration_last    = st.number_input("Last RR (breaths/min)",   0.0,  60.0, 18.0)
            respiration_mean_3h = st.number_input("Mean RR — 3h",            0.0,  60.0, 18.0)
            respiration_std_3h  = st.number_input("Std RR — 3h",             0.0,  15.0,  2.0)
            respiration_slope_3h= st.number_input("Slope RR — 3h",          -5.0,   5.0,  0.0)

        with col3:
            st.markdown("**🫁 Respiratory Support**")
            fio2_last           = st.number_input("FiO2 last (%)",           21.0, 100.0, 40.0)
            fio2_missing        = st.selectbox("FiO2 missing?", [0, 1], format_func=lambda x: "Yes" if x else "No")
            peep_last           = st.number_input("PEEP last (cmH2O)",        0.0,  25.0,  5.0)
            on_oxygen_therapy   = st.selectbox("On oxygen therapy?", [0, 1], format_func=lambda x: "Yes" if x else "No")
            on_noninvasive_vent = st.selectbox("On non-invasive vent?", [0, 1], format_func=lambda x: "Yes" if x else "No")

            st.markdown("**🏥 ICU Unit Type**")
            unit_options = ["CCU-CTICU", "CSICU", "CTICU", "Cardiac ICU", "MICU", "Med-Surg ICU", "Neuro ICU", "SICU"]
            unit_type = st.selectbox("Unit Type", unit_options, index=4)

        submitted = st.form_submit_button("🔮 Predict Risk", type="primary", disabled=not model_ready)

    if submitted and model_ready:
        # Build feature vector
        unit_onehot = {f"unittype_{u}": 1 if u == unit_type else 0 for u in unit_options}
        input_dict = {
            "heartrate_last": heartrate_last, "sao2_last": sao2_last,
            "respiration_last": respiration_last, "fio2_last": fio2_last, "peep_last": peep_last,
            "on_oxygen_therapy": on_oxygen_therapy, "on_noninvasive_vent": on_noninvasive_vent,
            "age": age, "admissionweight": admissionweight,
            "heartrate_mean_3h": heartrate_mean_3h, "heartrate_std_3h": heartrate_std_3h,
            "heartrate_slope_3h": heartrate_slope_3h,
            "sao2_mean_3h": sao2_mean_3h, "sao2_std_3h": sao2_std_3h, "sao2_slope_3h": sao2_slope_3h,
            "respiration_mean_3h": respiration_mean_3h, "respiration_std_3h": respiration_std_3h,
            "respiration_slope_3h": respiration_slope_3h,
            "hr_missing": hr_missing, "sao2_missing": sao2_missing, "fio2_missing": fio2_missing,
            "gender_Female": 1 if gender_female == "Female" else 0,
            "gender_Male":   1 if gender_female == "Male"   else 0,
            **unit_onehot,
        }

        features = st.session_state["pred_features"]
        X_input  = pd.DataFrame([input_dict])[features]
        model    = st.session_state["pred_model"]

        prob     = model.predict_proba(X_input)[0][1]
        THRESHOLD = 0.40

        # ── Result display ────────────────────────────────────────────────────
        st.markdown("---")
        st.subheader("🩺 Prediction Result")

        col_res, col_gauge = st.columns([1, 1])

        with col_res:
            if prob >= THRESHOLD:
                st.error(f"""
### 🚨 HIGH RISK — Ventilation Likely
**Probability: {prob:.1%}**

This patient shows risk factors consistent with requiring mechanical ventilation in the next **6–12 hours**.

**Recommended actions:**
- Notify attending physician immediately
- Prepare ventilation equipment
- Increase monitoring frequency
                """)
            else:
                st.success(f"""
### ✅ LOW RISK — No Immediate Action
**Probability: {prob:.1%}**

Current vitals do not indicate imminent ventilation need within the next 6–12 hours.

**Recommended:**
- Continue routine monitoring
- Re-assess if vitals deteriorate
                """)

            st.metric("Risk Score",   f"{prob:.1%}")
            st.metric("Threshold",    f"{THRESHOLD:.0%}")
            st.metric("Decision",     "⚠️ High Risk" if prob >= THRESHOLD else "✅ Low Risk")

        with col_gauge:
            fig, ax = plt.subplots(figsize=(5, 4))
            color = "#dc2626" if prob >= THRESHOLD else "#16a34a"
            ax.barh(["Risk"], [prob], color=color, height=0.4)
            ax.barh(["Risk"], [1 - prob], left=[prob], color="#e5e7eb", height=0.4)
            ax.axvline(THRESHOLD, color="orange", linestyle="--", lw=2, label=f"Threshold={THRESHOLD:.0%}")
            ax.set_xlim(0, 1)
            ax.set_xlabel("Probability of Ventilation")
            ax.set_title(f"Risk: {prob:.1%}")
            ax.legend(); ax.grid(axis="x", alpha=0.3)
            plt.tight_layout()
            st.pyplot(fig)
