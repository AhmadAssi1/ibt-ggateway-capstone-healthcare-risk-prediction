import streamlit as st

def show():
    st.title("🫁 ICU Mechanical Ventilation Risk Predictor")
    st.markdown("### Early warning system for ICU patients — predicts ventilation need 6–12 hours ahead")
    st.markdown("---")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Training Rows",   "109,474")
    col2.metric("Test Rows",       "27,393")
    col3.metric("Features",        "31")
    col4.metric("Class Imbalance", "437 : 1")

    st.markdown("---")

    col_l, col_r = st.columns(2)

    with col_l:
        st.subheader("🎯 Objective")
        st.info(
            "Build a classification model to predict whether an ICU patient "
            "will require **mechanical ventilation in the next 6–12 hours**.\n\n"
            "- **Target:** `y_high = 1` in the 6–12h window before ventilation\n"
            "- **Primary metric:** AUPRC (preferred for severe class imbalance)\n"
            "- **Secondary metric:** AUROC"
        )

        st.subheader("📁 Data Sources")
        sources = {
            "patient.csv":             "Demographics & stay info",
            "respiratoryCare.csv":     "Ventilation events → labels",
            "respiratoryCharting.csv": "Respiratory vitals over time",
            "vitalPeriodic.csv":       "Heart rate, SpO2, respiration",
            "vitalAperiodic.csv":      "Non-invasive blood pressure",
            "treatment.csv":           "Clinical treatments applied",
        }
        for f, desc in sources.items():
            st.markdown(f"- **`{f}`** — {desc}")

    with col_r:
        st.subheader("🔬 What is y_high?")
        st.warning(
            "Think of it like a **security camera** watching a patient every hour in the ICU.\n\n"
            "Every hour we take a snapshot of their vitals and ask:\n"
            "_\"Will this patient need a ventilator soon?\"_\n\n"
            "- 🚨 **y_high = 1** — Ventilator needed in 6–12 hours\n"
            "- ✅ **y_high = 0** — Patient is stable right now\n\n"
            "The **6–12 hour window** gives doctors enough warning time — "
            "not too early (weak signal), not too late (no time to act)."
        )

        st.subheader("🗺️ App Navigation")
        st.markdown("""
| Page | Description |
|------|-------------|
| 📊 EDA | Explore data distributions & missing values |
| 🤖 Model Training | Train models with chosen strategy |
| 📈 Results | Compare all experiments |
| 🔮 Predict | Run a single patient prediction |
        """)

    st.markdown("---")
    st.subheader("🧩 Feature Groups (31 features)")
    cols = st.columns(5)
    groups = {
        "❤️ Heart Rate":     ["heartrate_last", "heartrate_mean_3h", "heartrate_std_3h", "heartrate_slope_3h", "hr_missing"],
        "🫧 SpO2":           ["sao2_last", "sao2_mean_3h", "sao2_std_3h", "sao2_slope_3h", "sao2_missing"],
        "💨 Respiration":    ["respiration_last", "respiration_mean_3h", "respiration_std_3h", "respiration_slope_3h"],
        "🫁 Respiratory Rx": ["fio2_last", "peep_last", "on_oxygen_therapy", "on_noninvasive_vent", "fio2_missing"],
        "👤 Demographics":   ["age", "admissionweight", "gender_Female", "gender_Male"],
    }
    for col, (group, feats) in zip(cols, groups.items()):
        col.markdown(f"**{group}**")
        for f in feats:
            col.markdown(f"- `{f}`")
