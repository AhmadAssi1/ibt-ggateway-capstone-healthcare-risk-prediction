import streamlit as st

st.set_page_config(
    page_title="ICU Ventilation Predictor",
    page_icon="🫁",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Sidebar navigation ────────────────────────────────────────────────────────
st.sidebar.image("https://img.icons8.com/fluency/96/hospital.png", width=60)
st.sidebar.title("ICU Ventilation\nPredictor")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigate",
    ["🏠 Home", "📊 EDA", "🤖 Model Training", "📈 Results & Comparison", "🔮 Predict"],
    label_visibility="collapsed",
)

st.sidebar.markdown("---")
st.sidebar.caption("eICU Collaborative Research Database\nTarget: y_high — ventilation in 6–12h")

# ── Route pages ───────────────────────────────────────────────────────────────
if page == "🏠 Home":
    from pages import home;       home.show()
elif page == "📊 EDA":
    from pages import eda;        eda.show()
elif page == "🤖 Model Training":
    from pages import training;   training.show()
elif page == "📈 Results & Comparison":
    from pages import results;    results.show()
elif page == "🔮 Predict":
    from pages import predict;    predict.show()
